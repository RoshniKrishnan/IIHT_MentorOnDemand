
IF EXISTS (SELECT * FROM sys.databases WHERE name = N'mentor_on_demand')
BEGIN
	DROP DATABASE mentor_on_demand
	CREATE DATABASE mentor_on_demand
END
ELSE
BEGIN
	CREATE DATABASE mentor_on_demand
END
GO

USE mentor_on_demand
GO

/****** Object:  Table :- course ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE course(
	[id] [int] IDENTITY(1,1) NOT NULL,
	[course_name] [varchar](20) NOT NULL,
	[fee] [bigint] NOT NULL,
	[commission_amount] [bigint] NULL
 CONSTRAINT [PK_course] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT course ON
 INSERT INTO course (id,course_name,fee,commission_amount) VALUES
(1,'Java',2000,200),
(2,'Angular',9000,900),
(3,'Python',6000,800),
(4,'C#',3000,300);
SET IDENTITY_INSERT course Off

select * from course
delete from course

/****** Object:  Table :- user ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[user](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [varchar](20) NOT NULL,
	[last_name] [varchar](20) NOT NULL,
	[age] [int] NOT NULL,
	[location][varchar](30)NOT NULL,
	[contact_number][bigint] NOT NULL,
	[user_name][varchar](20) NOT NULL,
	[password] [varchar](20) NOT NULL,
	[role][varchar](10) NOT NULL,
CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT [dbo].[user] ON
 INSERT INTO [dbo].[user] (id,first_name,last_name,age,location,contact_number,user_name,password,role) VALUES
 (1,'Karthik','R',21,'Chennai',9532842567,'karthi@gmail.com','karthi123','admin'),
(2,'Roshni','Krishnan',22,'Chennai',9532842567,'roshni@gmail.com','rosh123','user'),
(3,'Abhjith','J',23,'Chennai',9532842567,'abhi@gmail.com','abhi123','user');
SET IDENTITY_INSERT [dbo].[user] Off

select * from [dbo].[user]



/****** Object:  Table :- mentor ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE mentor(
	[id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [varchar](20) NOT NULL,
	[last_name] [varchar](20) NOT NULL,
	[age] [int] NOT NULL,
	[location][varchar](30)NOT NULL,
	[linkedin_url][varchar](30)NOT NULL,
	[contact_number][bigint] NOT NULL,
	[year_of_experience][int] NOT NULL,
	[active][bit]NOT NULL,
	[course_name][varchar](20) NOT NULL,
	[user_name][varchar](20) NOT NULL,
	[password] [varchar](20) NOT NULL,
	[confirm_signup][bit] NULL,
	[reset_Password_date][date] NULL,
	[reset_password][bit] NULL
CONSTRAINT [PK_mentor] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT mentor ON
 INSERT INTO mentor (id,first_name,last_name,age,location,linkedin_url,contact_number,year_of_experience,active,course_name,user_name,password) VALUES
 (1,'Prakah','V',44,'Chennai','www.linkedin.com/in/prakash',9532842567,3,1,'C#','prakash@gmail.com','prakash123'),
 (2,'Joel','Thomas',24,'Chennai','www.linkedin.com/in/Joel',9532842567,3,1,'Java','joel@gmail.com','joel123'),
 (3,'Rohita','C',22,'Chennai','www.linkedin.com/in/rohita',9532842567,3,1,'Angular','rohita@gmail.com','rohita123');
SET IDENTITY_INSERT mentor Off

select * from mentor
delete from mentor

/****** Object:  Table :- reservation ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE training(
	[id] [int] IDENTITY(1,1) NOT NULL,
	[user_id] [int] NOT NULL,
	[mentor_id] [int] NOT NULL,
	[course_name] [varchar](20) NOT NULL,
	[start_date][date] NULL,
	[end_date][date] NULL,
	[status][bit] NOT NULL,
	[amount_paid][bigint] NULL,
	[progress][varchar](20) NULL,
	[amount_to_mentor][float] NULL,
	[completion_percentage][int] NULL,
	[rating][bigint] NULL
CONSTRAINT [PK_reservation] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE training  WITH CHECK ADD  CONSTRAINT [user_id_fk] FOREIGN KEY([user_id])
REFERENCES [dbo].[user] ([id])
GO
ALTER TABLE training CHECK CONSTRAINT [user_id_fk]
GO
ALTER TABLE training  WITH CHECK ADD  CONSTRAINT [mentor_id_fk] FOREIGN KEY([mentor_id])
REFERENCES mentor ([id])
GO
ALTER TABLE training CHECK CONSTRAINT [mentor_id_fk]
GO


SET IDENTITY_INSERT training ON
 INSERT INTO training (id,user_id,mentor_id,course_name,start_date,end_date,status,amount_paid,progress,amount_to_mentor,completion_percentage,rating) VALUES
(1,2,1,'C#','2020/2/4','2020/2/5',1,3000,'Accepted',null,0,NULL),
(2,2,1,'C#','2020/2/4','2020/2/5',1,3000,'In-Process',2000,null,3.5);
SET IDENTITY_INSERT training Off

select * from training
update training set progress= 'Accepted', status=1, completion_percentage=0 where id=1 
drop table training 
delete from training