﻿using System;
using System.Collections.Generic;

namespace MentorOnDemand.Models
{
    public partial class Course
    {
        public int Id { get; set; }
        public string CourseName { get; set; }
        public long Fee { get; set; }
        public long? CommissionAmount { get; set; }
    }
}
