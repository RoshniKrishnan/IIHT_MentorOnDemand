﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MentorOnDemand.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MentorOnDemand.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();


        [HttpGet]
        [Route("GetAllMentor")]
        public IActionResult GetAllMentor()
        {
            return Ok(mod.Mentor);
        }


        [HttpPost("{mentorId}/{status}")]
        public IActionResult BlockMentor(int mentorId,string status)
        {
            Mentor mentor = mod.Mentor.Where(m => m.Id == mentorId).FirstOrDefault();
            if(status=="block")
            {
                mentor.Active = false;
                mod.SaveChanges();
                return Ok(new { status = "Blocked" });
            }
            else
            {
                mentor.Active = true;
                mod.SaveChanges();
                return Ok(new { status = "Unblocked" });
            }
        }

        [HttpPost]
        public IActionResult AddNewCourse([FromBody] Course course)
        {
            Course newCourse = new Course();
            newCourse.CourseName = course.CourseName;
            newCourse.Fee = course.Fee;
            newCourse.CommissionAmount = course.CommissionAmount;
            mod.Course.Add(newCourse);
            mod.SaveChanges();
            return Ok(new { status = "New Course Added", course = newCourse });
        }

        [Route("ListCourse")]
        [HttpGet]
        public IActionResult ListAllCourses()
        {
            return Ok(mod.Course);
        }
    }
}