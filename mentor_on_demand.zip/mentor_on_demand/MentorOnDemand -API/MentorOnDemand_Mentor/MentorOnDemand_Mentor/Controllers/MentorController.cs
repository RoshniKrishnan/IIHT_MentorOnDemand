﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using MentorOnDemand_Mentor.Models;

namespace MentorOnDemand_Mentor.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class MentorController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();

        [HttpPost]
        [Route("MentorLogin")]
        public IActionResult MentorLogin([FromBody]credentials credentials)
        {
            var loggedUser = mod.Mentor.Where(u => u.UserName == credentials.UserName && u.Password == credentials.Password && u.Active == true).FirstOrDefault();
            if (loggedUser != null)
            {
                return Ok(new { status = "Matched", user = loggedUser });
            }
            else
            {
                return Ok(new { status = "No Match" });
            }
        }

        [HttpGet]
        [Route("GetAllMentor")]
        public IActionResult GetAllMentor()
        {
            return Ok(mod.Mentor.Where(mentor => mentor.Active == true));
        }

        [HttpPost]
        [Route("MentorSignUp")]
        public IActionResult SignUp([FromBody]Mentor mentor)
        {
            Mentor newMentor = new Mentor();
            newMentor.FirstName = mentor.FirstName;
            newMentor.LastName = mentor.LastName;
            newMentor.Age = mentor.Age;
            newMentor.Location = mentor.Location;
            newMentor.LinkedinUrl = mentor.LinkedinUrl;
            newMentor.ContactNumber = mentor.ContactNumber;
            newMentor.YearOfExperience = mentor.YearOfExperience;
            newMentor.Active = true;
            newMentor.CourseName = mentor.CourseName;
            newMentor.UserName = mentor.UserName;
            newMentor.Password = mentor.Password;
            mod.Mentor.Add(newMentor);
            mod.SaveChanges();
            return Ok(new { status = "Registered" });
        }


        [Route("RequestStatus/{id}/{status}")]
        [HttpPost("{id}/{status}")]
        public IActionResult RequestStatus(int id, string status)
        {
            Training training = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            training.Progress = status;
            training.Status = true;
            mod.SaveChanges();
            return Ok(new { status = "Updated" });
        }
    }
}