﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using MentorOnDemand_Progress.Models;

namespace MentorOnDemand_Progress.Controllers
{
    [EnableCors("MentorOnDemandPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProgressController : ControllerBase
    {
        mentor_on_demandContext mod = new mentor_on_demandContext();

        [HttpPut("{id}/{percentage}")]
        public IActionResult UpdateCompletionStatus(int id, int percentage)
        {
            Training myTraining = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            myTraining.CompletionPercentage = percentage;
            myTraining.Progress = "In-Progress";
            if (percentage == 25)
            {
                myTraining.AmountToMentor = myTraining.AmountPaid * 0.9 * 0.25;
            }

            if (percentage == 50)
            {
                myTraining.AmountToMentor = myTraining.AmountPaid * 0.9 * 0.5;
            }
            if (percentage == 75)
            {
                myTraining.AmountToMentor = myTraining.AmountPaid * 0.9 * 0.75;
            }
            mod.SaveChanges();
            return Ok(new { status = "Updated", training = myTraining });
        }

        [HttpPost("{id}/{percentage}/{rate}")]
        public IActionResult CompletionStatus(int id, int percentage, int rate)
        {
            Training myTraining = mod.Training.Where(t => t.Id == id).FirstOrDefault();
            myTraining.CompletionPercentage = percentage;
            myTraining.Progress = "Completed";
            myTraining.Rating = rate;
            myTraining.AmountToMentor = myTraining.AmountPaid * 0.9;
            myTraining.EndDate = DateTime.Now.Date;
            mod.SaveChanges();
            return Ok(new { status = "Updated", training = myTraining });
        }
    }
}