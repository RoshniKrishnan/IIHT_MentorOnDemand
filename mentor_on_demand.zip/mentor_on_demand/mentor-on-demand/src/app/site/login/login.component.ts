import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ModService } from 'src/app/service/mod.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm :FormGroup;
isAdmin:boolean
isUser:boolean
isMentor : boolean
submitted:boolean
isNotValidAdmin:boolean
isNotValidUser:boolean
isNotValidMentor:boolean
message:string
  constructor(private formBuilder: FormBuilder, private modService:ModService,private router:Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]]
  });
  }
  get formControls() { return this.loginForm.controls; }
  adminClick()
  {
    this.isAdmin = true;
    this.isMentor = false;
    this.isUser=false;
  }
  userClick()
  {
    this.isAdmin = false;
    this.isMentor = false;
    this.isUser=true;
  }
  mentorClick()
  {
    this.isAdmin = false;
    this.isMentor = true;
    this.isUser=false;
  }
  onAdminSubmit()
  {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    if(this.submitted)
    {
      this.modService.adminAuthenticate(this.loginForm).subscribe(
        data => {
          console.log(data) 
          if(data['status'] == "Matched")
          {
            this.modService.loggedIn = data['user']
            this.modService.isAdmin = this.modService.loggedIn.role == "admin" ? true : false
            console.log(this.modService.loggedIn)
            console.log(this.modService.isAdmin)
            if(this.modService.isAdmin)
            {
              console.log("Welcome Admin");
              this.router.navigateByUrl("blockMentor");
            }
          }
          else if(data['status'] == "No Match")
          {
            this.isNotValidAdmin=true;
            this.isNotValidUser=false
            this.isNotValidMentor=false
            console.log(this.isNotValidAdmin)
          }
        },
        error => console.log(error) )
      }  
    }

    onUserSubmit()
    {
      this.submitted = true;
      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }
      if(this.submitted)
      {
        this.modService.userAuthenticate(this.loginForm).subscribe(
          data => {
            console.log(data) 
            if(data['status'] == "Matched")
            {
              this.modService.loggedIn = data['user']
              this.modService.isUser = this.modService.loggedIn.role == "user" ? true : false
              console.log(this.modService.loggedIn)
              console.log(this.modService.isUser)
              if(this.modService.isUser)
              {
                console.log("Welcome User");
                this.router.navigateByUrl("userTraining");
              }
            }
            else if(data['status'] == "No Match")
            {
              this.isNotValidAdmin=false;
              this.isNotValidUser=true
              this.isNotValidMentor=false
              console.log(this.isNotValidUser)
            }
          },
          error => console.log(error) )
        }  
      }

      onMentorSubmit()
      {
        this.submitted = true;
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }
        if(this.submitted)
        {
          this.modService.mentorAuthenticate(this.loginForm).subscribe(
            data => {
              console.log(data) 
              if(data['status'] == "Matched")
              {
                this.modService.isMentor=true;
                this.modService.loggedIn = data['user']
                console.log(this.modService.loggedIn)
                if(!this.modService.isAdmin)
                {
                  console.log("Welcome Mentor");
                   this.router.navigateByUrl("mentorTraining");
                }
              }
              else if(data['status'] == "No Match")
              {         
                this.isNotValidAdmin=false;
                this.isNotValidUser=false
                this.isNotValidMentor=true
                console.log(this.isNotValidMentor)
              }
            },
            error => console.log(error) )
          }  
        }



  }