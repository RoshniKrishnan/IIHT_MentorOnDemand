import { Component, OnInit } from '@angular/core';
import { ModService } from 'src/app/service/mod.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private modService: ModService, private router:Router) { }
role:string
  ngOnInit() {
    
  }

  getRole()
  {
    if(this.modService.isAdmin)
      this.role = "Admin"
      if(this.modService.isUser)
       {
        this.role = "User"
        console.log(this.role)
       } 
      if(this.modService.isMentor)
        this.role ="Mentor"
      return this.role
   }

  getUser()
  {
    return this.modService.loggedIn
  }
  onLogout()
  {
    this.modService.loggedIn = null
    this.modService.isAdmin = null
    this.modService.isMentor=null
    this.modService.isUser=null
    this.role ="null"
    this.router.navigateByUrl('/login')
  }


}
