import { Injectable } from '@angular/core';
import { ModService } from './mod.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Training } from '../models/training';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  baseUrl = "http://localhost:5020/api"

  constructor(private modService :ModService,private http :HttpClient) { }

  getUserTraining()
  {
    let data =this.modService.loggedIn.id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.http.get<Training[]>(this.baseUrl+"/training/GetUserTraining/"+data,options))
    return this.http.get<Training[]>(this.baseUrl+"/training/GetUserTraining/"+data,options)
  }
  getMentorTraining()
  {
    let data =this.modService.loggedIn.id
    console.log("data")
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.http.get<Training[]>(this.baseUrl+"/training/GetMentorTraining/"+data,options))
    return this.http.get<Training[]>(this.baseUrl+"/training/GetMentorTraining/"+data,options)
  }
  getTraining(trainingId:number)
  {
    let data = trainingId
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/training/getTraining/"+data,options)
  }
  startTraining(trainingId:number)
  {
    let data = trainingId
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/training/StartTraining/"+data,options)
  }

  UpdateCompletionStatus(id:number,percentage:number){
    let data =id+"/"+percentage;
    console.log(data);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.http.put(this.baseUrl+"/progress/"+data,options))
    return this.http.put("http://localhost:5040/api/progress/"+data,options)
  }
  
  CompletionStatus(id:number,percentage:number,rate:number)
  {
    let data =id+"/"+percentage+"/"+rate;
    console.log(data);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.http.post(this.baseUrl+"/progress/"+data,options))
    return this.http.post("http://localhost:5040/api/progress/"+data,options)
  }
  requestStatus(id:number,status:string)
  {
    let data=id+"/"+status;
    console.log(data);
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.http.post(this.baseUrl+"/mentor/RequestStatus/"+data,options))
    return this.http.post("http://localhost:5030/api/mentor/RequestStatus/"+data,options)
  }
  
}
