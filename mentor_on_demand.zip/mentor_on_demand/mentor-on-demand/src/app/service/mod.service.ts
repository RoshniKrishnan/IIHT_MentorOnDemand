import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class ModService {
  baseUrl = "http://localhost:5000/api";
  loggedIn:User
  isAdmin:boolean
  isMentor:boolean
  isUser:boolean
  mentorList:any
  constructor(private http:HttpClient) { }

  //login
  adminAuthenticate(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5010/api/user/UserLogin/admin",body,options)
  }
  userAuthenticate(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5010/api/user/UserLogin/user",body,options)
  }
  mentorAuthenticate(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    console.log(body)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post("http://localhost:5030/api/mentor/MentorLogin",body,options)
  }

  //signup
  userSignup(userDetails:any)
  {
    let body = JSON.stringify(userDetails.value)
    console.log(body)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.post("http://localhost:5010/api/user/UserSignup",body,options)
  }
  mentorSignup(userDetails:any)
  {
    let body = JSON.stringify(userDetails.value)
    console.log(body)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    console.log(this.baseUrl+"/mentor/MentorSignUp")
    return this.http.post("http://localhost:5030/api/mentor/MentorSignUp",body,options)
  }

  getAllMentors()
  { 
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    console.log(this.baseUrl+"/mentor/GetAllMentor")
    return this.http.get("http://localhost:5030/api/mentor/GetAllMentor",options)
}

RequestMentor(mentorId:number,userId:number)
{
  let data =mentorId+"/"+userId;
  console.log(data);
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  console.log(this.http.post(this.baseUrl+"/user/RequestForMentor/"+data,options))
  return this.http.post("http://localhost:5010/api/user/RequestForMentor/"+data,options)
}
blockMentor(mentorId:number,status:string)
{
  let data =mentorId+"/"+status;
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
  let options = { headers: header };
  console.log(this.http.post(this.baseUrl+"/admin/"+data,options))
  return this.http.post("http://localhost:5000/api/admin/"+data,options)
}
adminGetAllMentors()
{
  let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    console.log(this.baseUrl+"/admin/GetAllMentor")
    return this.http.get("http://localhost:5000/api/admin/GetAllMentor",options)
}

}
