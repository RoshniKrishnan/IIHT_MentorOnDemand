import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './site/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { UserSignupComponent } from './signup/user-signup/user-signup.component';
import { MentorSignupComponent } from './signup/mentor-signup/mentor-signup.component';
import { SuccessComponent } from './signup/success/success.component';
import { UserTrainingComponent } from './user/user-training/user-training.component';
import { DatePipe } from '@angular/common';
import { MentorTrainingComponent } from './mentor/mentor-training/mentor-training.component';
import { ProceedTrainingComponent } from './user/proceed-training/proceed-training.component';
import { MentorDetailsComponent } from './mentor/mentor-details/mentor-details.component';
import { TrainingProgressComponent } from './user/training-progress/training-progress.component';
import { HeaderComponent } from './site/header/header.component';
import { MentorSearchComponent } from './mentor/mentor-search/mentor-search.component';
import { BlockMentorComponent } from './admin/block-mentor/block-mentor.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserSignupComponent,
    MentorSignupComponent,
    SuccessComponent,
    UserTrainingComponent,
    MentorTrainingComponent,
    ProceedTrainingComponent,
    MentorDetailsComponent,
    TrainingProgressComponent,
    HeaderComponent,
    MentorSearchComponent,
    BlockMentorComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
