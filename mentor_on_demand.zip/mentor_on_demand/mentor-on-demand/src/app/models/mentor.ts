export class Mentor
{
    id:number;
    firstName:string;
    lastName:string;
    age:number;
    location:string;
    linkedinUrl:string;
    contactNumber:number;
    yearOfExperience:number;
    courseName:string
    userName:string;
    password:string;
}