export class User
{
    id:number;
    firstName:string;
    lastName:string;
    age:number;
    location:string;
    contactNumber:number;
    userName:string;
    password:string;
    role:string;
}