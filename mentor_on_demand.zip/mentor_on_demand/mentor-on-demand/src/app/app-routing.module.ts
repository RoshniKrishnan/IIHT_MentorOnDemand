import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { UserSignupComponent } from './signup/user-signup/user-signup.component';
import { MentorSignupComponent } from './signup/mentor-signup/mentor-signup.component';
import { SuccessComponent } from './signup/success/success.component';
import { UserTrainingComponent } from './user/user-training/user-training.component';
import { MentorTrainingComponent } from './mentor/mentor-training/mentor-training.component';
import { ProceedTrainingComponent } from './user/proceed-training/proceed-training.component';
import { MentorDetailsComponent } from './mentor/mentor-details/mentor-details.component';
import { TrainingProgressComponent } from './user/training-progress/training-progress.component';
import { MentorSearchComponent } from './mentor/mentor-search/mentor-search.component';
import { BlockMentorComponent } from './admin/block-mentor/block-mentor.component';
import { AuthGuard } from './guard/auth.guard';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'userSignup', component:UserSignupComponent},
  {path:'mentorSignup', component:MentorSignupComponent},
  {path:'success', component:SuccessComponent},
  {path:'userTraining', component:UserTrainingComponent,canActivate:[AuthGuard]},
  {path:'mentorTraining', component:MentorTrainingComponent,canActivate:[AuthGuard]},
  {path:'proceedTraining/:trainingId', component:ProceedTrainingComponent,canActivate:[AuthGuard]},
  {path:'mentorList', component:MentorDetailsComponent,canActivate:[AuthGuard]},
  {path:'trainingProgress/:trainingId', component:TrainingProgressComponent,canActivate:[AuthGuard]},
  {path:'mentorSearch', component:MentorSearchComponent},
  {path:'blockMentor', component:BlockMentorComponent,canActivate:[AuthGuard]},
  {path:'',redirectTo:'mentorSearch',pathMatch:'full'} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
