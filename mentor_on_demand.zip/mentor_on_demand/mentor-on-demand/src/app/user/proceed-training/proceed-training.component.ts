import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TrainingService } from 'src/app/service/training.service';
import { Training } from 'src/app/models/training';

@Component({
  selector: 'app-proceed-training',
  templateUrl: './proceed-training.component.html',
  styleUrls: ['./proceed-training.component.css']
})
export class ProceedTrainingComponent implements OnInit {
trainingId:number
newTraining:Training
showModal:boolean=false
  constructor(private activatedRoute:ActivatedRoute,private trainingService:TrainingService, private router :Router) { }

  ngOnInit() {
    this.trainingId = this.activatedRoute.snapshot.params['trainingId'] as number
    // console.log(this.trainingId)
    this.trainingService.getTraining(this.trainingId).subscribe(
      data=>{
        this.newTraining = data;
        console.log(this.newTraining)
      }
    )
  }
  onPay()
  {
    this.showModal=true
  }
  onStartTraining(trainingId:number)
  {
    console.log(trainingId)
    this.trainingService.startTraining(trainingId).subscribe(
      data=>{
        console.log(data)
      }
      
    )
    this.router.navigateByUrl('trainingProgress/'+trainingId)
  }



}
