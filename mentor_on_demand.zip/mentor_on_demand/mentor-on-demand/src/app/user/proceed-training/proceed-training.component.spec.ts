import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProceedTrainingComponent } from './proceed-training.component';

describe('ProceedTrainingComponent', () => {
  let component: ProceedTrainingComponent;
  let fixture: ComponentFixture<ProceedTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProceedTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProceedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
