import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/service/training.service';
import { Training } from 'src/app/models/training';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-training',
  templateUrl: './user-training.component.html',
  styleUrls: ['./user-training.component.css']
})
export class UserTrainingComponent implements OnInit {

  mytrainings:Training[]
  isAll: boolean
  today = new Date()
  isUndergoing: boolean
  isUpcoming: boolean
  isPrevious:boolean
  isRequest: boolean
  constructor(private trainingService:TrainingService, private router:Router) { }

  ngOnInit() {
    this.isAll = true
    this.trainingService.getUserTraining().subscribe(
      data=>{
        console.log(data)
        this.mytrainings=data;
        this.mytrainings=this.mytrainings.sort()
      }
    )
  }
  onAll()
  {
    this.isAll = true
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUndergoing()
  {
    this.isAll = false
    this.isUndergoing = true
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUpcoming()
  {
    this.isAll = false
    this.isUndergoing = false
    this.isUpcoming =  true
    this.isRequest = false
    this.isPrevious = false
  }
  onPrevious()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = true
  }
  onRequest()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = true
    this.isPrevious = false
  }

  undergoing()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="In-Progress" && mytraining.status==true) 
  }
  upcoming()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="Accepted")
  }
  request()
  {
    return this.mytrainings.filter(mytraining => mytraining.status==false && mytraining.progress=="Requested") 
  }
  previous()
  {
    return this.mytrainings.filter(mytraining =>  mytraining.progress=="Completed" &&  mytraining.status==true)
  }
  
  viewTraining(trainingId:number)
  {
    this.router.navigateByUrl('trainingProgress/'+trainingId)
  }
  proceedTraining(trainingId:number)
  {
    this.router.navigateByUrl('proceedTraining/'+trainingId)
  }
}
