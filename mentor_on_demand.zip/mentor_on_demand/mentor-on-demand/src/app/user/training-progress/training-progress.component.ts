import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TrainingService } from 'src/app/service/training.service';
import { Training } from 'src/app/models/training';

@Component({
  selector: 'app-training-progress',
  templateUrl: './training-progress.component.html',
  styleUrls: ['./training-progress.component.css']
})
export class TrainingProgressComponent implements OnInit {

  firstQuarter:boolean=false;
secondQuarter:boolean=false
thirdQuarter:boolean=false
fourthQuarter:Boolean=false
Completed:boolean
rate:boolean
  constructor(private activateroute:ActivatedRoute,private trainingService:TrainingService,private router:Router) { }

  trainingId:number;
  myTraining:Training
  status:Training
  ngOnInit() {
    this.trainingId= this.activateroute.snapshot.params['trainingId'];
    console.log(this.trainingId)
    this.trainingService.getTraining(this.trainingId).subscribe(
      data=>{

        this.myTraining=data
        console.log(this.myTraining[0])
        if(this.myTraining[0].completionPercentage == 0)
        {
          this.firstQuarter=true
        }
        if(this.myTraining[0].completionPercentage == 25)
        {
          this.secondQuarter=true 
        }
        if(this.myTraining[0].completionPercentage == 50)
        {
          this.thirdQuarter=true 
        }
        if(this.myTraining[0].completionPercentage == 75)
        {
          this.fourthQuarter=true 
        }
        console.log(this.myTraining)
      })
  }

  CompletionFirstQuater(){
    this.trainingService.UpdateCompletionStatus(this.trainingId,25).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==25)
        {
          this.firstQuarter=false
          this.secondQuarter=true
          this.thirdQuarter=false
          this.fourthQuarter=false
        }
      }
    )
  }

  CompletionSecondQuater(){
    this.trainingService.UpdateCompletionStatus(this.trainingId,50).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==50)
        {
          this.firstQuarter=false
          this.secondQuarter=false
          this.thirdQuarter=true
          this.fourthQuarter=false
        }
      }
    )
  }
  CompletionThirdQuater(){
    this.trainingService.UpdateCompletionStatus(this.trainingId,75).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==75)
        {
          this.firstQuarter=false
          this.secondQuarter=false
          this.thirdQuarter=false
          this.fourthQuarter=true
        }
      }
    )
  }
  CompletionLastQuater(){
    this.Completed = true;
  }
  UserRating(rate:number)
  {
    this.rate= true
    this.trainingService.CompletionStatus(this.trainingId,100,rate).subscribe(
      data=>{
        console.log(data)
        this.status = data['training']
        if(this.status.completionPercentage==25)
        {
          this.firstQuarter=false
          this.secondQuarter=true
          this.thirdQuarter=false
          this.fourthQuarter=false
        }
      })
    }
    }
    
