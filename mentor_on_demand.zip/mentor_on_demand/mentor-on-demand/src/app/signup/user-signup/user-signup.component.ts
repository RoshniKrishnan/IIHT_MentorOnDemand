import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ModService } from 'src/app/service/mod.service';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {
submitted:boolean=false;
  userRegisterForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router:Router,private modService:ModService) { }

  ngOnInit() {
    this.userRegisterForm=this.formBuilder.group({
            
      firstName: new FormControl('',[Validators.required,]),
      lastName: new FormControl('', [Validators.required]),
      age:new FormControl('',[Validators.required,Validators.pattern("[0-9]*$"),Validators.maxLength(2),Validators.minLength(1)]),
      location: new FormControl('',[Validators.required]),
      contactNumber: new FormControl('',[Validators.required,,Validators.pattern("[0-9]*$")]),
      userName:new FormControl('', [Validators.required, Validators.email]),
      password:new FormControl('',[Validators.required, Validators.minLength(8)])
    });
  }

  onUserRegSubmit(){
    this.submitted =true;
    console.log("Registered")
    console.log(this.userRegisterForm.value)
    this.modService.userSignup(this.userRegisterForm).subscribe(
      data => {
        console.log(data)
        if(data['status'] == "Registered")
            {
              this.router.navigateByUrl("success")
            }
      }
    )
  }
  get f(){
    return this.userRegisterForm.controls;
    
  }


}
