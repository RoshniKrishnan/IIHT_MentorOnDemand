import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ModService } from 'src/app/service/mod.service';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  submitted:boolean=false;
  mentorRegisterForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router:Router,private modService:ModService) { }

  ngOnInit() {
    this.mentorRegisterForm=this.formBuilder.group({
            
      firstName: new FormControl('',[Validators.required,]),
      lastName: new FormControl('', [Validators.required]),
      yearOfExperience:new FormControl('',[Validators.required,Validators.pattern("[0-9]*$")]),
      linkedinUrl: new FormControl('', [Validators.required]),
      location: new FormControl('',[Validators.required]),
      contactNumber: new FormControl('',[Validators.required,,Validators.pattern("[0-9]*$")]),
      userName:new FormControl('', [Validators.required, Validators.email]),
      password:new FormControl('',[Validators.required, Validators.minLength(8)]),
      courseName:new FormControl('',[Validators.required])
    });

  }

  onMentorRegSubmit(){
    this.submitted =true;
    console.log("Registered")
    console.log(this.mentorRegisterForm.value)
    this.modService.mentorSignup(this.mentorRegisterForm).subscribe(
      data => {
        console.log(data)

        if(data['status'] == "Registered")
            {     
              this.router.navigateByUrl("success")
            }
      }
    )
  }
  get f(){
    return this.mentorRegisterForm.controls;
    
  }


}
