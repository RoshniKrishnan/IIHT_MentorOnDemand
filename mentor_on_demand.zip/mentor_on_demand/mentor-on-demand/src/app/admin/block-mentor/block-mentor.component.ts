import { Component, OnInit } from '@angular/core';
import { ModService } from 'src/app/service/mod.service';

@Component({
  selector: 'app-block-mentor',
  templateUrl: './block-mentor.component.html',
  styleUrls: ['./block-mentor.component.css']
})
export class BlockMentorComponent implements OnInit {

  courses:any
  mentorList:any
  fullMentorList:any
  selectedMentor
  blocked
  unblocked
    constructor(private modService:ModService) { }
  
    ngOnInit() {
      this.modService.adminGetAllMentors().subscribe(
        data => {
          console.log(data)
          this.courses=this.mentorList=data;
          this.fullMentorList=this.mentorList
      }
       ) 
    }
    onSearch(event:any)
    {
      if(event.target.value == '')
      {
        this.courses = this.fullMentorList
      }
      else
      {
        this.courses = this.courses.filter(course => course.courseName.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()))
      }
    }

  blockMentor(id:number,status:string)
  {
    this.selectedMentor=id
    if(status=="block")
      this.blocked=true;
    else
      this.unblocked=true;
    this.modService.blockMentor(id,status).subscribe(
      data => {
        console.log(data)

  })

  }

}
