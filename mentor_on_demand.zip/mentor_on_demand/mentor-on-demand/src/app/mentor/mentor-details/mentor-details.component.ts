import { Component, OnInit } from '@angular/core';
import { ModService } from 'src/app/service/mod.service';

@Component({
  selector: 'app-mentor-details',
  templateUrl: './mentor-details.component.html',
  styleUrls: ['./mentor-details.component.css']
})
export class MentorDetailsComponent implements OnInit {
  courses:any
  mentorList:any
  fullMentorList:any
  selectedMentor
  proposed
    constructor(private modService:ModService) { }
  
    ngOnInit() {
      this.modService.getAllMentors().subscribe(
        data => {
          console.log(data)
          this.courses=this.mentorList=data;
          this.fullMentorList=this.mentorList
      }
       ) 
    }
    onSearch(event:any)
  {
    if(event.target.value == '')
    {
      this.courses = this.fullMentorList
    }
    else
    {
      this.courses = this.courses.filter(course => course.courseName.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()))
    }
  }

  propose(id:number)
  {
    this.selectedMentor=id
    this.proposed=true;
    this.modService.RequestMentor(id,this.modService.loggedIn.id).subscribe(
      data => {
        console.log(data)

  })

  }

  }


