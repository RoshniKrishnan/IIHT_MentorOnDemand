import { Component, OnInit } from '@angular/core';
import { Training } from 'src/app/models/training';
import { TrainingService } from 'src/app/service/training.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-mentor-training',
  templateUrl: './mentor-training.component.html',
  styleUrls: ['./mentor-training.component.css']
})
export class MentorTrainingComponent implements OnInit {
  mytrainings:Training[]
  isAll: boolean
  today = new Date()
  isUndergoing: boolean
  isUpcoming: boolean
  isPrevious:boolean
  isRequest: boolean
  status:string
  constructor(private trainingService:TrainingService,private datepipe: DatePipe) { }

  ngOnInit() {
    this.isAll = true
    this.trainingService.getMentorTraining().subscribe(
      data=>{
        console.log(data)
        this.mytrainings=data;
        this.mytrainings=this.mytrainings.sort()
      }
    )
  }
  onAll()
  {
    this.isAll = true
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUndergoing()
  {
    this.isAll = false
    this.isUndergoing = true
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = false
  }
  onUpcoming()
  {
    this.isAll = false
    this.isUndergoing = false
    this.isUpcoming =  true
    this.isRequest = false
    this.isPrevious = false
  }
  onPrevious()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = false
    this.isPrevious = true
  }
  onRequest()
  {
    this.isAll =  false
    this.isUndergoing = false
    this.isUpcoming = false
    this.isRequest = true
    this.isPrevious = false
  }

  undergoing()
  {
    return this.mytrainings.filter(mytraining => mytraining.progress=="In-Progress" && mytraining.status==true) 
  }
  upcoming()
  {
    return this.mytrainings.filter(mytraining => mytraining.startDate.toString() > this.datepipe.transform(this.today, 'yyyy-MM-dd') &&  mytraining.status==true)
  }
  request()
  {
    return this.mytrainings.filter(mytraining => mytraining.status==false && mytraining.progress=="Requested") 
  }
  previous()
  {
    return this.mytrainings.filter(mytraining =>  mytraining.progress=="Completed" &&  mytraining.status==true)
  }

  reject(id:number)
  {
    this.status ="rejected";
     this.trainingService.requestStatus(id,"Rejected").subscribe(
      data=>{
        console.log(data)
      }
    )
  }
  accept(id:number)
  {
    this.status ="accepted";
     this.trainingService.requestStatus(id,"Accepted").subscribe(
      data=>{
        console.log(data)
      }
    )
  }
}
