import { Component, OnInit } from '@angular/core';
import { ModService } from 'src/app/service/mod.service';

@Component({
  selector: 'app-mentor-search',
  templateUrl: './mentor-search.component.html',
  styleUrls: ['./mentor-search.component.css']
})
export class MentorSearchComponent implements OnInit {
  courses:any
  mentorList:any
  fullMentorList:any
    constructor(private modService:ModService) { }
  
    ngOnInit() {
      this.modService.getAllMentors().subscribe(
        data => {
          console.log(data)
          this.courses=this.mentorList=data;
          this.fullMentorList=this.mentorList
      }
       ) 
    }
    onSearch(event:any)
  {
    if(event.target.value == '')
    {
      this.courses = this.fullMentorList
    }
    else
    {
      this.courses = this.courses.filter(course => course.courseName.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase()))
    }
  }


}
